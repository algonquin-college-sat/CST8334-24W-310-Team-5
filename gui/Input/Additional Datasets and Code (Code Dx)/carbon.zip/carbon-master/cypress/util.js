export const environment = { width: 1000, height: 768, name: 'chrome' }
